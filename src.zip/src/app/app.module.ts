import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProjModule } from './projmodule';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DialogComponent } from './dialog/dialog.component';
import { ContactDialogComponent } from './contact-dialog/contact-dialog.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RegisterStepperComponent } from './register-stepper/register-stepper.component';
import {ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { FormserviceService } from './formservice.service';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    DashboardComponent,
    DialogComponent,
    ContactDialogComponent,
    RegisterStepperComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ProjModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
