import { Injectable } from '@angular/core';
import { RegistrationForm } from './models/RegistrationForm';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { identifierName } from '@angular/compiler';
import {map} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class FormserviceService {
  loggedInUser:string;

  constructor( private http:HttpClient) { }
  postData(data:RegistrationForm){
    return this.http.post<RegistrationForm>("http://localhost:3000/posts",data)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  getData(id:string){
    return this.http.get<RegistrationForm>("http://localhost:3000/posts/"+id)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  deleteData(id:number){
    return this.http.delete<RegistrationForm>("http://localhost:3000/posts/"+id)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  editData(data:RegistrationForm,id:string){
    return this.http.put<RegistrationForm>("http://localhost:3000/posts/"+id,data)
    .pipe(map((res:any)=>{
       return res;}))
  }
}
