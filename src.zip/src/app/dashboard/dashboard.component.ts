import { Component } from '@angular/core';
import {FormBuilder} from '@angular/forms';
import{Validators} from '@angular/forms';
import{FormGroup,Form} from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  constructor(private router:Router){}
  toRegiser(){
    this.router.navigate(['register']);
  }
}
