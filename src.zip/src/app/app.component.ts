import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ContactDialogComponent } from './contact-dialog/contact-dialog.component';
import { DialogComponent } from './dialog/dialog.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Project3';
  constructor(public dialog: MatDialog,public router:Router) {
    
  }
  toLogin(){
    this.router.navigate(['/login']);
  }
  toRegistration(){
    this.router.navigate(['/registration']);
  }
  openDialog(){
    this.dialog.open(DialogComponent),{
    width:'250px',
    height:'250px',
  }
}
  openContactDialog(){
    this.dialog.open(ContactDialogComponent),{
    width:'250px',
    height:'250px',
  }
  }
}
