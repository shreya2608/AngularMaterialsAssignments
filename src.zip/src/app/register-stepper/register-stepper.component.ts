import { Component, Input, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { FormserviceService } from '../formservice.service';
import { RegistrationForm } from '../models/RegistrationForm';

@Component({
  selector: 'app-register-stepper',
  templateUrl: './register-stepper.component.html',
  styleUrls: ['./register-stepper.component.css']
})
export class RegisterStepperComponent implements OnInit {
  firstFormGroup = this._formBuilder.group({
    fCtrl: ['', Validators.required]
  })
  secondFormGroup = this._formBuilder.group({
    sCtrl: ['', Validators.required]
  })
  formRegister: FormGroup;
  formObj: RegistrationForm = new RegistrationForm();
  emailpattern!: "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  namepattern!: "^[a-zA-Z ]{2,20}$";
  constructor(private _formBuilder: FormBuilder, private service: FormserviceService, private router: Router) { }
  setValueState() {
    this.formRegister = this._formBuilder.group({
      name: new FormControl('', [Validators.compose([Validators.required, Validators.pattern(this.namepattern), Validators.min(6), Validators.max(32)])]),
      email: new FormControl('', Validators.compose([Validators.required, Validators.pattern(this.emailpattern)])),
      gender: new FormControl('', [Validators.required]),
      dob: new FormControl('', [Validators.required]),
      phone: new FormControl('', Validators.compose([Validators.required, Validators.min(10), Validators.max(10)])),
      presentaddress: new FormControl('', [Validators.required]),
      permanentaddress: new FormControl('', [Validators.required]),
      mothername: new FormControl('', [Validators.compose([Validators.required, Validators.pattern(this.namepattern), Validators.min(6), Validators.max(32)])]),
      fathername: new FormControl('', [Validators.compose([Validators.required, Validators.pattern(this.namepattern), Validators.min(6), Validators.max(32)])]),
      accountname: new FormControl(''),
      accountno: new FormControl('', [Validators.pattern("/^\d+$/")]),
      bankname: new FormControl(''),
      ifsc: new FormControl(''),
      mobilebanking: new FormControl(''),
      internetbanking: new FormControl('')
    });
  }
  ngOnInit() {
    this.setValueState();
  }
  onSubmit() {
    if (this.formRegister.valid) {
      this.postData();
      this.service.editData(this.formObj, this.service.loggedInUser)
        .subscribe(res => {
          console.log(res);
          alert("success");
          this.router.navigate(['/dashboard']);
        },
          err => {
            alert("error");
          }
        );
    }
  }
  postData() {
    this.service.getData(this.service.loggedInUser)
      .subscribe(user => {
        this.formObj.id = user.username;
        this.formObj.password = user.password;
        this.formObj.skills = user.skills;
      });
    this.formObj.name = this.formRegister.value.name;
    this.formObj.email = this.formRegister.value.email;
    this.formObj.gender = this.formRegister.value.gender;
    this.formObj.dob = this.formRegister.value.dob;
    this.formObj.phone = this.formRegister.value.phone;
    this.formObj.presentaddress = this.formRegister.value.presentaddress;
    this.formObj.permanentaddress = this.formRegister.value.permanentaddress;
    this.formObj.mothername = this.formRegister.value.mothername;
    this.formObj.fathername = this.formRegister.value.fathername;
    this.formObj.accountname = this.formRegister.value.accountname;
    this.formObj.accountno = this.formRegister.value.accountno;
    this.formObj.bankname = this.formRegister.value.bankname;
    this.formObj.ifsc = this.formRegister.value.ifsc;
    this.formObj.mobilebanking = this.formRegister.value.mobilebanking;
    this.formObj.internetbanking = this.formRegister.value.internetbanking;
  }
}
