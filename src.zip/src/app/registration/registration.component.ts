import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup,FormBuilder,FormControl, Validators} from '@angular/forms';
import { FormserviceService} from '../formservice.service';
import { OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { RegistrationForm } from '../models/RegistrationForm';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  genders:string[]=['Male','Female'];
  skills:string[]=['Angular Basic','Angular Intermediate','Angular Advanced'];
  myForm:FormGroup;
  formObj:RegistrationForm= new RegistrationForm();
  constructor(private router:Router,private services:FormserviceService,private fb: FormBuilder) { }
  onSubmit(){
    this.postData();
    this.services.postData(this.formObj).subscribe(res=>{
      console.log(res);
      alert("Success!");}
      );
    this.router.navigate(['/login']);
  }
  postData(){
    this.formObj.name=this.myForm.value.name;
    this.formObj.id=this.myForm.value.username;
    this.formObj.email=this.myForm.value.email;
    this.formObj.password=this.myForm.value.password;
    this.formObj.gender=this.myForm.value.gender;
    this.formObj.dob=this.myForm.value.dob;
    this.formObj.phone=this.myForm.value.phone;
    this.formObj.skills=this.myForm.value.skills;
    this.formObj.presentaddress="";
    this.formObj.permanentaddress="";
    this.formObj.mothername="";
    this.formObj.fathername="";
    this.formObj.accountname="";
    this.formObj.accountno=0;
    this.formObj.bankname="";
    this.formObj.ifsc="";
    this.formObj.mobilebanking="";
    this.formObj.internetbanking="";
  }
  setformState() {
    this.myForm = new FormGroup({
      fullname: new FormControl('',[Validators.required]),
      phone: new FormControl('', Validators.compose([Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)])),
      email: new FormControl('', Validators.compose([Validators.required, Validators.pattern("^[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*$")])),
      username: new FormControl('', Validators.compose([Validators.required])),
      gender: new FormControl('', Validators.compose([Validators.required])),
      dob: new FormControl('', Validators.compose([Validators.required])),
      skills: new FormControl('', Validators.compose([Validators.required])),
      password: new FormControl('', Validators.compose([Validators.required, Validators.minLength(6)]))
    });
  }
  ngOnInit() {
    this.setformState();
    }
}