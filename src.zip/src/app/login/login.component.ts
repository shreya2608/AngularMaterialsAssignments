import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FormserviceService } from '../formservice.service';
import { RegistrationForm } from '../models/RegistrationForm';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:FormGroup;
  details: RegistrationForm;
  constructor(public router:Router,private service:FormserviceService, fb:FormBuilder) { }
  onSubmit(){
    this.service.getData(this.loginForm.value.username)
    .subscribe(user=>{
      if (user.id === this.loginForm.value.username && user.password === this.loginForm.value.password){
        this.router.navigate(['/dashboard']);
        this.service.loggedInUser=this.loginForm.value.username;
        alert('Success');
      }
      else{
        alert('Incorrect password')
      }
    },
    err=>{
      alert('User not Found!');
    }
      );
    
  }
  setFormState(){
    this.loginForm=new FormGroup({
      username: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    });
  }
  ngOnInit(){
    this.setFormState();
  }
}
